using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager : MonoBehaviour
{
    public GameObject[] animalPrefabs;

    private float spawnRangeX = 17f;
    private float spawnPosZ = 20f;
    private float spawnDelay = 2f;
    private float spawnInterval = 1.5f;

    // Start is called before the first frame update
    void Start()
    {
        // time interval for spawn
            // method invoked, spawn delay, spawn intervals
        InvokeRepeating("SpawnRandomAnimal", spawnDelay, spawnInterval);
    }

    void SpawnRandomAnimal()
    {
        // random range of animals 0 - 3 ( 0, 1, 2 )
        int animalIndex = Random.Range(0, animalPrefabs.Length);
        // random position to spawn
        Vector3 spawnPosition = new Vector3(Random.Range(-spawnRangeX, spawnRangeX), 0, spawnPosZ);

        // spawn new object[array of animals], spawn location, rotation (where it faces)
        Instantiate(animalPrefabs[animalIndex], spawnPosition, animalPrefabs[animalIndex].transform.rotation);
    }
}
