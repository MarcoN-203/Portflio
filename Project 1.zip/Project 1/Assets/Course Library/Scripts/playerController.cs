using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerController : MonoBehaviour
{
    public float horizontalInput;
    private float speed = 35;
    private float xRange = 18f;

    public GameObject bullet;

    void Update()
    {
        OutOfBounds();  

        horizontalInput = Input.GetAxis("Horizontal");
        transform.Translate(Vector3.right * horizontalInput * speed * Time.deltaTime);

        LaunchProjectile();
    }
    void OutOfBounds()
    {
        if (transform.position.x < -xRange)
        {
            transform.position = new Vector3(-xRange, transform.position.y, transform.position.z);
        }
        if (transform.position.x > xRange)
        {
            transform.position = new Vector3(xRange, transform.position.y, transform.position.z);
        }
    }
    void LaunchProjectile()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            //launch projectile
                // object, position of spawn, rotation of object when spawned
                // sandwhich, player's position, sandwich facing forward
            Instantiate(bullet, transform.position, bullet.transform.rotation);
        }
    }
}
