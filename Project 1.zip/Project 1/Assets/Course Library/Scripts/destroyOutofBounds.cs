using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class destroyOutofBounds : MonoBehaviour
{
    private float topBoundry = 40;
    private float lowerBoundry = -10;

    void Update()
    {
        if (transform.position.z > topBoundry)
        {
            Destroy(gameObject);
        }
        else if (transform.position.z < lowerBoundry)
        {
            Destroy(gameObject);
            Debug.Log("Game Over!");
        }
    }
}
